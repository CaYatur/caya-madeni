package net.mcreator.cayamadeni.procedures;

import net.mcreator.cayamadeni.CayaMadeniModElements;

import java.util.Map;

@CayaMadeniModElements.ModElement.Tag
public class DenemeKomutCalistirildigindaProcedure extends CayaMadeniModElements.ModElement {
	public DenemeKomutCalistirildigindaProcedure(CayaMadeniModElements instance) {
		super(instance, 147);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
