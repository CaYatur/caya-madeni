package net.mcreator.cayamadeni.procedures;

import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.cayamadeni.CayaMadeniModElements;
import net.mcreator.cayamadeni.CayaMadeniMod;

import java.util.Map;

@CayaMadeniModElements.ModElement.Tag
public class RoketMenzilliSilahKullanildigindatProcedure extends CayaMadeniModElements.ModElement {
	public RoketMenzilliSilahKullanildigindatProcedure(CayaMadeniModElements instance) {
		super(instance, 155);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CayaMadeniMod.LOGGER.warn("Failed to load dependency entity for procedure RoketMenzilliSilahKullanildigindat!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.INSTANT_HEALTH, (int) 30, (int) 1));
	}
}
