package net.mcreator.cayamadeni.procedures;

import net.mcreator.cayamadeni.CayaMadeniModElements;

import java.util.Map;

@CayaMadeniModElements.ModElement.Tag
public class CokgucedHavayaSagTiklandigindaProcedure extends CayaMadeniModElements.ModElement {
	public CokgucedHavayaSagTiklandigindaProcedure(CayaMadeniModElements instance) {
		super(instance, 90);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
